import { Agent, agentMap } from "../data/agents";

interface Props {
  agent: Agent;
  onClose: () => void;
}

export default function AgentDetail({ agent, onClose }: Props) {
  const claudeMdContent = `# ${agent.fullName} 配置

## 身份声明
AGENT_ID=${agent.id}
AGENT_NAME=${agent.name}
AGENT_ROLE=${agent.role}

## 层级关系
SUPERIOR=${agent.superiors.join(",") || "none"}
SUBORDINATES=${agent.subordinates.join(",") || "none"}

## 路径配置
AGENT_DIR=D:\\sslb\\${agent.id}
INBOX=${agent.dir}\\inbox
OUTBOX=${agent.dir}\\outbox
REPORTS=${agent.dir}\\reports

## 消息总线
MESSAGE_BUS=D:\\sslb\\.bus
STATUS_FILE=${agent.dir}\\.status

## 模型配置
${agent.hasClaude ? `CLAUDE_ENABLED=true` : `CLAUDE_ENABLED=false`}
${agent.hasQwen ? `QWEN_ENABLED=true` : `QWEN_ENABLED=false`}

## 任务职责
${agent.description}

## 输入格式（JSON）
{
  "task_id": "string",
  "from": "string",
  "command": "string",
  "context": {},
  "priority": "high|medium|low"
}

## 输出格式（JSON）
{
  "task_id": "string",
  "status": "done|failed|pending",
  "result": {},
  "report_file": "reports/YYYYMMDD_taskid.md"
}`;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className={`bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[85vh] overflow-hidden border-2 ${agent.borderColor}`}>
        {/* Header */}
        <div className={`${agent.bgColor} px-6 py-4 flex items-center justify-between`}>
          <div className="flex items-center gap-3">
            <span className="text-3xl">{agent.icon}</span>
            <div>
              <h2 className={`text-xl font-bold ${agent.color}`}>{agent.fullName}</h2>
              <p className="text-sm text-gray-500">{agent.role} · {agent.dir}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-2xl leading-none"
          >
            ×
          </button>
        </div>

        <div className="overflow-y-auto max-h-[calc(85vh-80px)]">
          {/* Info Cards */}
          <div className="px-6 pt-4 grid grid-cols-3 gap-3">
            <div className="bg-gray-50 rounded-lg p-3 text-center">
              <div className="text-xs text-gray-400 mb-1">上级</div>
              <div className="font-semibold text-sm text-gray-700">
                {agent.superiors.length
                  ? agent.superiors.map((id) => agentMap[id]?.name).join("、")
                  : "无（最高层）"}
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3 text-center">
              <div className="text-xs text-gray-400 mb-1">下辖</div>
              <div className="font-semibold text-sm text-gray-700">
                {agent.subordinates.length
                  ? `${agent.subordinates.length} 个部门`
                  : "无（执行层）"}
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3 text-center">
              <div className="text-xs text-gray-400 mb-1">支持模型</div>
              <div className="flex gap-1 justify-center">
                {agent.hasClaude && (
                  <span className="text-xs bg-orange-100 text-orange-700 px-2 py-0.5 rounded-full">Claude</span>
                )}
                {agent.hasQwen && (
                  <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Qwen</span>
                )}
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="px-6 pt-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-base">📝</span>
              <h3 className="font-semibold text-gray-700">职责描述</h3>
            </div>
            <p className="text-sm text-gray-600 bg-gray-50 rounded-lg p-3">{agent.description}</p>
          </div>

          {/* CLAUDE.md Content */}
          <div className="px-6 pt-4 pb-6">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-base">📄</span>
              <h3 className="font-semibold text-gray-700">推荐 CLAUDE.md 配置</h3>
              <span className="text-xs text-gray-400">{agent.dir}\CLAUDE.md</span>
            </div>
            <pre className="text-xs bg-gray-900 text-green-400 rounded-xl p-4 overflow-x-auto leading-relaxed">
              {claudeMdContent}
            </pre>
          </div>

          {/* Inbox/Outbox structure */}
          <div className="px-6 pb-6">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-base">📁</span>
              <h3 className="font-semibold text-gray-700">建议目录结构</h3>
            </div>
            <pre className="text-xs bg-gray-900 text-cyan-400 rounded-xl p-4 overflow-x-auto leading-relaxed">
{`D:\\sslb\\${agent.id}\\
├── CLAUDE.md          # 智能体配置
├── inbox\\             # 接收上级命令（JSON）
├── outbox\\            # 输出结果（JSON）
├── reports\\           # 生成报告（MD）
├── .status            # 当前状态文件
${agent.hasClaude ? `├── start-claude.bat   # 启动 Claude\n` : ""}${agent.hasQwen ? `└── start-qwen.bat     # 启动 Qwen\n` : ""}`}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
