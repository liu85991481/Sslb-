import { agents, Agent } from "../data/agents";

interface Props {
  onSelectAgent: (agent: Agent) => void;
  selectedId: string | null;
}

export default function FlowDiagram({ onSelectAgent, selectedId }: Props) {
  const top = agents.find((a) => a.id === "zhongshusheng")!;
  const middle = agents.filter((a) => a.superiors.includes("zhongshusheng"));
  const bottom = agents.filter((a) => a.superiors.includes("shangshusheng"));

  const NodeBox = ({ agent }: { agent: Agent }) => (
    <div
      onClick={() => onSelectAgent(agent)}
      className={`cursor-pointer rounded-xl border-2 px-3 py-2 text-center transition-all duration-200 hover:scale-105 hover:shadow-lg ${
        selectedId === agent.id
          ? `${agent.borderColor} ${agent.bgColor} shadow-lg scale-105`
          : "border-gray-200 bg-white hover:border-gray-300"
      }`}
      style={{ minWidth: 90 }}
    >
      <div className="text-2xl mb-0.5">{agent.icon}</div>
      <div className={`font-bold text-xs ${selectedId === agent.id ? agent.color : "text-gray-700"}`}>
        {agent.name}
      </div>
      <div className="text-gray-400 text-xs">{agent.role}</div>
      <div className="flex gap-0.5 justify-center mt-1">
        {agent.hasClaude && <span className="text-xs bg-orange-100 text-orange-600 px-1 rounded">C</span>}
        {agent.hasQwen && <span className="text-xs bg-blue-100 text-blue-600 px-1 rounded">Q</span>}
      </div>
    </div>
  );

  return (
    <div className="flex flex-col items-center gap-0 select-none w-full overflow-x-auto pb-2">
      {/* Top Level */}
      <div className="flex justify-center">
        <NodeBox agent={top} />
      </div>

      {/* Arrow down */}
      <div className="flex justify-center gap-16 w-full relative">
        {/* vertical line from zhongshusheng */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 bg-yellow-400" style={{ height: 20 }} />
        {/* horizontal line */}
        <div className="absolute top-5 left-1/2 -translate-x-1/2" style={{ width: "40%", height: 2, background: "#facc15" }} />
        {/* two vertical drops */}
        <div className="absolute top-5 left-1/4 w-0.5 bg-yellow-400" style={{ height: 20 }} />
        <div className="absolute top-5 right-1/4 w-0.5 bg-yellow-400" style={{ height: 20 }} />
      </div>

      {/* Middle Level: menxiasheng + shangshusheng */}
      <div className="flex justify-center gap-8 mt-5">
        {middle.map((a) => (
          <NodeBox key={a.id} agent={a} />
        ))}
      </div>

      {/* Arrow from shangshusheng */}
      <div className="relative flex justify-end w-full" style={{ height: 40 }}>
        {/* vertical from shangshusheng (right half) */}
        <div
          className="absolute bg-purple-400"
          style={{ width: 2, height: 40, right: "calc(25% - 1px)", top: 0 }}
        />
        {/* horizontal across bottom */}
        <div
          className="absolute bg-purple-400"
          style={{ height: 2, right: "10%", left: "30%", top: 38 }}
        />
        {/* 6 vertical drops */}
        {[10, 22, 34, 46, 58, 70].map((pct, i) => (
          <div
            key={i}
            className="absolute bg-purple-400"
            style={{ width: 2, height: 15, left: `${pct}%`, top: 38 }}
          />
        ))}
      </div>

      {/* Bottom Level: 6 bu */}
      <div className="flex flex-wrap justify-center gap-2 mt-1">
        {bottom.map((a) => (
          <NodeBox key={a.id} agent={a} />
        ))}
      </div>
    </div>
  );
}
