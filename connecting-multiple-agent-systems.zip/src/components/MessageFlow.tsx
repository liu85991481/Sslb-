import { useState, useEffect } from "react";

interface MessageStep {
  from: string;
  to: string;
  content: string;
  type: "command" | "review" | "execute" | "report";
  icon: string;
}

const FLOW: MessageStep[] = [
  {
    from: "用户/触发器",
    to: "中书省",
    content: '{"task": "分析市场数据并生成报告", "priority": "high"}',
    type: "command",
    icon: "🚀",
  },
  {
    from: "中书省",
    to: "门下省",
    content: '{"decision": "需要数据分析", "route": "shangshusheng->gongbu", "review": true}',
    type: "review",
    icon: "🔍",
  },
  {
    from: "门下省",
    to: "中书省",
    content: '{"approved": true, "notes": "合规，可执行"}',
    type: "review",
    icon: "✅",
  },
  {
    from: "中书省",
    to: "尚书省",
    content: '{"command": "执行数据分析任务", "assign_to": "gongbu", "deadline": "2h"}',
    type: "command",
    icon: "⚖️",
  },
  {
    from: "尚书省",
    to: "工部",
    content: '{"task": "数据分析", "tools": ["python", "pandas"], "output": "report.md"}',
    type: "execute",
    icon: "🔧",
  },
  {
    from: "工部",
    to: "尚书省",
    content: '{"status": "done", "report": "reports/20250101_analysis.md", "summary": "..."}',
    type: "report",
    icon: "📊",
  },
  {
    from: "尚书省",
    to: "中书省",
    content: '{"all_tasks": "completed", "reports": ["gongbu/reports/..."], "duration": "1.5h"}',
    type: "report",
    icon: "📋",
  },
];

const typeColor: Record<string, string> = {
  command: "border-yellow-400 bg-yellow-50",
  review: "border-blue-400 bg-blue-50",
  execute: "border-purple-400 bg-purple-50",
  report: "border-green-400 bg-green-50",
};

const typeLabel: Record<string, string> = {
  command: "🟡 命令下发",
  review: "🔵 审核流程",
  execute: "🟣 任务执行",
  report: "🟢 结果上报",
};

export default function MessageFlow() {
  const [visibleCount, setVisibleCount] = useState(0);
  const [running, setRunning] = useState(false);

  const start = () => {
    setVisibleCount(0);
    setRunning(true);
  };

  useEffect(() => {
    if (!running) return;
    if (visibleCount >= FLOW.length) {
      setRunning(false);
      return;
    }
    const timer = setTimeout(() => {
      setVisibleCount((c) => c + 1);
    }, 800);
    return () => clearTimeout(timer);
  }, [running, visibleCount]);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex gap-3 flex-wrap">
          {Object.entries(typeLabel).map(([k, v]) => (
            <span key={k} className="text-xs text-gray-500">{v}</span>
          ))}
        </div>
        <button
          onClick={start}
          disabled={running}
          className="text-sm bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300 text-white px-4 py-1.5 rounded-lg font-medium transition-colors"
        >
          {running ? "⏳ 模拟中..." : "▶ 开始模拟"}
        </button>
      </div>

      {FLOW.map((msg, i) =>
        i < visibleCount ? (
          <div
            key={i}
            className={`flex items-start gap-3 border-l-4 rounded-r-xl p-3 transition-all duration-500 ${typeColor[msg.type]}`}
            style={{ animation: "fadeSlideIn 0.4s ease" }}
          >
            <span className="text-2xl">{msg.icon}</span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-bold text-gray-700 text-sm">{msg.from}</span>
                <span className="text-gray-400">→</span>
                <span className="font-bold text-gray-700 text-sm">{msg.to}</span>
                <span className="text-xs text-gray-400 ml-auto">步骤 {i + 1}/{FLOW.length}</span>
              </div>
              <pre className="text-xs text-gray-600 bg-white/60 rounded p-2 overflow-x-auto">
                {msg.content}
              </pre>
            </div>
          </div>
        ) : i === visibleCount && running ? (
          <div
            key={i}
            className="flex items-center gap-2 text-gray-400 text-sm px-4 py-2"
          >
            <div className="flex gap-1">
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
            </div>
            正在传递消息...
          </div>
        ) : null
      )}

      {visibleCount === 0 && !running && (
        <div className="text-center py-8 text-gray-400">
          <div className="text-4xl mb-2">📬</div>
          <p className="text-sm">点击「开始模拟」查看消息在各智能体间的传递过程</p>
        </div>
      )}

      {visibleCount >= FLOW.length && (
        <div className="text-center py-4 bg-green-50 border-2 border-green-400 rounded-xl">
          <div className="text-2xl mb-1">🎉</div>
          <p className="text-sm font-semibold text-green-700">任务完成！消息流程模拟结束</p>
        </div>
      )}
    </div>
  );
}
