import { useState } from "react";

interface Step {
  step: number;
  title: string;
  icon: string;
  color: string;
  desc: string;
  code: string;
}

interface Props {
  step: Step;
  defaultOpen?: boolean;
}

export default function ConfigStep({ step, defaultOpen }: Props) {
  const [open, setOpen] = useState(defaultOpen ?? false);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(step.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-xl border border-gray-200 overflow-hidden shadow-sm">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-5 py-4 bg-white hover:bg-gray-50 transition-colors text-left"
      >
        <div className={`${step.color} text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold flex-shrink-0`}>
          {step.step}
        </div>
        <span className="text-lg">{step.icon}</span>
        <div className="flex-1">
          <div className="font-semibold text-gray-800">{step.title}</div>
          <div className="text-sm text-gray-500">{step.desc}</div>
        </div>
        <svg
          className={`w-5 h-5 text-gray-400 transition-transform ${open ? "rotate-180" : ""}`}
          fill="none" viewBox="0 0 24 24" stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      {open && (
        <div className="border-t border-gray-100">
          <div className="relative">
            <button
              onClick={handleCopy}
              className="absolute top-3 right-3 z-10 text-xs bg-white/10 hover:bg-white/20 text-green-300 border border-green-700 px-2 py-1 rounded transition-colors"
            >
              {copied ? "✅ 已复制" : "📋 复制"}
            </button>
            <pre className="bg-gray-900 text-green-400 text-xs p-5 overflow-x-auto leading-relaxed">
              {step.code}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
