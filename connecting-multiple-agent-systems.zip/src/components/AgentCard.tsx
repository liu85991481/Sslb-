import { Agent, agentMap } from "../data/agents";

interface Props {
  agent: Agent;
  onClick: (agent: Agent) => void;
  selected: boolean;
}

export default function AgentCard({ agent, onClick, selected }: Props) {
  return (
    <div
      onClick={() => onClick(agent)}
      className={`cursor-pointer rounded-xl border-2 p-3 transition-all duration-200 hover:shadow-md ${
        selected
          ? `${agent.borderColor} ${agent.bgColor} shadow-md scale-105`
          : "border-gray-200 bg-white hover:border-gray-300"
      }`}
    >
      <div className="flex items-center gap-2 mb-1">
        <span className="text-xl">{agent.icon}</span>
        <div>
          <div className={`font-bold text-sm ${selected ? agent.color : "text-gray-800"}`}>
            {agent.name}
          </div>
          <div className="text-xs text-gray-400">{agent.role}</div>
        </div>
      </div>
      <div className="flex gap-1 mt-2">
        {agent.hasClaude && (
          <span className="text-xs bg-orange-100 text-orange-700 px-1.5 py-0.5 rounded-full">Claude</span>
        )}
        {agent.hasQwen && (
          <span className="text-xs bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded-full">Qwen</span>
        )}
      </div>
      {agent.subordinates.length > 0 && (
        <div className="mt-2 text-xs text-gray-400">
          下辖: {agent.subordinates.map((id) => agentMap[id]?.name).join("、")}
        </div>
      )}
    </div>
  );
}
