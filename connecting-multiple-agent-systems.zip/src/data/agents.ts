export interface Agent {
  id: string;
  name: string;
  fullName: string;
  dir: string;
  color: string;
  bgColor: string;
  borderColor: string;
  icon: string;
  role: string;
  description: string;
  hasClaude: boolean;
  hasQwen: boolean;
  subordinates: string[];
  superiors: string[];
}

export const agents: Agent[] = [
  {
    id: "zhongshusheng",
    name: "中书省",
    fullName: "中书省智能体",
    dir: "D:\\sslb\\zhongshusheng",
    color: "text-yellow-700",
    bgColor: "bg-yellow-50",
    borderColor: "border-yellow-400",
    icon: "👑",
    role: "最高决策层",
    description: "负责政令起草、最终决策，统筹协调所有下级部门",
    hasClaude: true,
    hasQwen: true,
    subordinates: ["menxiasheng", "shangshusheng"],
    superiors: [],
  },
  {
    id: "menxiasheng",
    name: "门下省",
    fullName: "门下省智能体",
    dir: "D:\\sslb\\menxiasheng",
    color: "text-blue-700",
    bgColor: "bg-blue-50",
    borderColor: "border-blue-400",
    icon: "🔍",
    role: "审核复议层",
    description: "负责审核中书省政令，驳回不合规内容，监督执行",
    hasClaude: true,
    hasQwen: false,
    subordinates: [],
    superiors: ["zhongshusheng"],
  },
  {
    id: "shangshusheng",
    name: "尚书省",
    fullName: "尚书省智能体",
    dir: "D:\\sslb\\shangshusheng",
    color: "text-purple-700",
    bgColor: "bg-purple-50",
    borderColor: "border-purple-400",
    icon: "⚖️",
    role: "执行调度层",
    description: "负责将政令分发至六部，统筹执行工作",
    hasClaude: true,
    hasQwen: false,
    subordinates: ["libu", "hubu", "liyibu", "bingbu", "xingbu", "gongbu"],
    superiors: ["zhongshusheng"],
  },
  {
    id: "libu",
    name: "吏部",
    fullName: "吏部智能体",
    dir: "D:\\sslb\\libu",
    color: "text-green-700",
    bgColor: "bg-green-50",
    borderColor: "border-green-400",
    icon: "📋",
    role: "人事管理",
    description: "负责智能体档案管理、能力评估与任务分配",
    hasClaude: true,
    hasQwen: false,
    subordinates: [],
    superiors: ["shangshusheng"],
  },
  {
    id: "hubu",
    name: "户部",
    fullName: "户部智能体",
    dir: "D:\\sslb\\hubu",
    color: "text-emerald-700",
    bgColor: "bg-emerald-50",
    borderColor: "border-emerald-400",
    icon: "💰",
    role: "资源管理",
    description: "负责系统资源调度、Token消耗统计与预算管理",
    hasClaude: true,
    hasQwen: false,
    subordinates: [],
    superiors: ["shangshusheng"],
  },
  {
    id: "liyibu",
    name: "礼仪部",
    fullName: "礼仪部智能体",
    dir: "D:\\sslb\\liyibu",
    color: "text-pink-700",
    bgColor: "bg-pink-50",
    borderColor: "border-pink-400",
    icon: "🎭",
    role: "规范制定",
    description: "负责制定智能体交互规范、提示词标准与输出格式",
    hasClaude: true,
    hasQwen: true,
    subordinates: [],
    superiors: ["shangshusheng"],
  },
  {
    id: "bingbu",
    name: "兵部",
    fullName: "兵部智能体",
    dir: "D:\\sslb\\bingbu",
    color: "text-red-700",
    bgColor: "bg-red-50",
    borderColor: "border-red-400",
    icon: "⚔️",
    role: "安全防护",
    description: "负责系统安全、异常检测、攻击防御与应急响应",
    hasClaude: true,
    hasQwen: false,
    subordinates: [],
    superiors: ["shangshusheng"],
  },
  {
    id: "xingbu",
    name: "刑部",
    fullName: "刑部智能体",
    dir: "D:\\sslb\\xingbu",
    color: "text-orange-700",
    bgColor: "bg-orange-50",
    borderColor: "border-orange-400",
    icon: "⚖️",
    role: "合规审计",
    description: "负责日志审计、违规处理、合规检查与问责机制",
    hasClaude: true,
    hasQwen: false,
    subordinates: [],
    superiors: ["shangshusheng"],
  },
  {
    id: "gongbu",
    name: "工部",
    fullName: "工部智能体",
    dir: "D:\\sslb\\gongbu",
    color: "text-cyan-700",
    bgColor: "bg-cyan-50",
    borderColor: "border-cyan-400",
    icon: "🔧",
    role: "技术执行",
    description: "负责代码生成、工具调用、技术任务的具体执行",
    hasClaude: true,
    hasQwen: true,
    subordinates: [],
    superiors: ["shangshusheng"],
  },
];

export const agentMap = Object.fromEntries(agents.map((a) => [a.id, a]));

export const configSteps = [
  {
    step: 1,
    title: "配置 CLAUDE.md 通信协议",
    icon: "📄",
    color: "bg-blue-500",
    desc: "在每个智能体的 CLAUDE.md 中定义：自身角色、上级/下级关系、消息格式、输出路径",
    code: `# 智能体身份
AGENT_ID=zhongshusheng
AGENT_ROLE=决策层
SUPERIOR=none
SUBORDINATES=menxiasheng,shangshusheng

# 消息总线路径
MESSAGE_BUS=D:\\sslb\\.bus\\
INBOX=D:\\sslb\\zhongshusheng\\inbox\\
OUTBOX=D:\\sslb\\zhongshusheng\\outbox\\

# 报告路径
REPORTS_DIR=D:\\sslb\\zhongshusheng\\reports\\`,
  },
  {
    step: 2,
    title: "建立消息总线目录",
    icon: "📬",
    color: "bg-green-500",
    desc: "创建共享消息目录，各智能体通过读写 JSON 文件实现通信",
    code: `mkdir D:\\sslb\\.bus
mkdir D:\\sslb\\.bus\\inbox
mkdir D:\\sslb\\.bus\\outbox
mkdir D:\\sslb\\.bus\\logs

# 消息格式 message.json
{
  "from": "zhongshusheng",
  "to": "shangshusheng",
  "type": "command",
  "task_id": "task_001",
  "content": "请分配以下任务至工部...",
  "timestamp": "2025-01-01T10:00:00Z",
  "priority": "high"
}`,
  },
  {
    step: 3,
    title: "配置 main.py 调度核心",
    icon: "🐍",
    color: "bg-yellow-500",
    desc: "通过 my_agent_project/main.py 实现智能体的启动、监听与消息路由",
    code: `# main.py 核心逻辑
import subprocess, json, time
from pathlib import Path

BUS_DIR = Path("D:/sslb/.bus")
AGENTS = {
    "zhongshusheng": "D:/sslb/zhongshusheng/start-claude.bat",
    "shangshusheng": "D:/sslb/shangshusheng/start-claude.bat",
    "gongbu": "D:/sslb/gongbu/start-qwen.bat",
    # ... 其他智能体
}

def dispatch_message(msg: dict):
    target = msg["to"]
    inbox = Path(f"D:/sslb/{target}/inbox")
    inbox.mkdir(exist_ok=True)
    fname = inbox / f"{msg['task_id']}.json"
    fname.write_text(json.dumps(msg, ensure_ascii=False))

def start_agent(agent_id: str):
    bat = AGENTS[agent_id]
    subprocess.Popen([bat], shell=True)`,
  },
  {
    step: 4,
    title: "修改 .bat 文件传递上下文",
    icon: "🦇",
    color: "bg-purple-500",
    desc: "让每个 start-claude.bat 启动时自动读取 inbox 并注入任务到提示词",
    code: `@echo off
REM start-claude.bat (以 gongbu 为例)
SET AGENT_DIR=D:\\sslb\\gongbu
SET INBOX=%AGENT_DIR%\\inbox
SET OUTBOX=%AGENT_DIR%\\outbox

REM 读取最新任务
for /f %%i in ('dir /b /o-d %INBOX%\\*.json') do (
    SET TASK_FILE=%INBOX%\\%%i
    goto :found
)
:found

REM 启动 Claude 并传入任务文件
claude --context %TASK_FILE% --output %OUTBOX%\\result.json

REM 通知主调度器任务完成
echo done > %AGENT_DIR%\\.status`,
  },
  {
    step: 5,
    title: "配置 prompts.py 提示词模板",
    icon: "💬",
    color: "bg-red-500",
    desc: "为每个智能体定制系统提示词，明确职责边界和输出格式",
    code: `# prompts.py
SYSTEM_PROMPTS = {
    "zhongshusheng": """
你是中书省智能体，负责最高决策。
收到任务后，你需要：
1. 分析任务优先级
2. 起草执行命令
3. 发送至门下省审核 或 尚书省执行
输出格式：JSON {"decision":..., "route_to":..., "priority":...}
""",
    "gongbu": """
你是工部智能体，负责技术执行。
收到命令后，你需要：
1. 解析任务需求
2. 调用相应工具/生成代码
3. 将结果写入 outbox/result.json
""",
}`,
  },
  {
    step: 6,
    title: "启动与监控",
    icon: "🚀",
    color: "bg-indigo-500",
    desc: "通过主调度器启动整个系统，监控各智能体状态",
    code: `# 启动整个系统
python D:\\sslb\\my_agent_project\\main.py --mode=orchestrator

# 或手动按层级启动
# 1. 先启动中书省
D:\\sslb\\zhongshusheng\\start-claude.bat

# 2. 中书省下发命令后，调度器自动唤醒对应智能体
# 3. 查看报告
dir D:\\sslb\\zhongshusheng\\reports\\
dir D:\\sslb\\gongbu\\reports\\`,
  },
];
