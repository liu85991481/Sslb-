import { useState } from "react";
import { agents, Agent, configSteps } from "./data/agents";
import AgentCard from "./components/AgentCard";
import AgentDetail from "./components/AgentDetail";
import ConfigStep from "./components/ConfigStep";
import FlowDiagram from "./components/FlowDiagram";
import MessageFlow from "./components/MessageFlow";

type Tab = "overview" | "config" | "flow" | "checklist";

export default function App() {
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [detailAgent, setDetailAgent] = useState<Agent | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>("overview");

  const tabs: { id: Tab; label: string; icon: string }[] = [
    { id: "overview", label: "系统总览", icon: "🏛️" },
    { id: "config", label: "配置指南", icon: "⚙️" },
    { id: "flow", label: "消息流转", icon: "📬" },
    { id: "checklist", label: "连通检查", icon: "✅" },
  ];

  const checklistItems = [
    {
      category: "目录结构",
      icon: "📁",
      color: "text-blue-600",
      items: [
        { label: "每个智能体目录下创建 inbox/ 文件夹", cmd: "mkdir D:\\sslb\\<agent>\\inbox" },
        { label: "每个智能体目录下创建 outbox/ 文件夹", cmd: "mkdir D:\\sslb\\<agent>\\outbox" },
        { label: "创建全局消息总线目录 .bus/", cmd: "mkdir D:\\sslb\\.bus" },
        { label: "确保 reports/ 目录存在（已有）", cmd: "已满足 ✓" },
      ],
    },
    {
      category: "CLAUDE.md 配置",
      icon: "📄",
      color: "text-purple-600",
      items: [
        { label: "zhongshusheng/CLAUDE.md 声明最高层角色", cmd: "点击左侧智能体查看模板" },
        { label: "menxiasheng/CLAUDE.md 声明审核职责", cmd: "点击左侧智能体查看模板" },
        { label: "shangshusheng/CLAUDE.md 声明调度职责", cmd: "点击左侧智能体查看模板" },
        { label: "六部 CLAUDE.md 各自声明执行职责", cmd: "点击对应智能体查看模板" },
      ],
    },
    {
      category: ".bat 文件改造",
      icon: "🦇",
      color: "text-orange-600",
      items: [
        { label: "start-claude.bat 启动时读取 inbox/ 最新任务", cmd: "见配置指南步骤4" },
        { label: "start-claude.bat 将结果写入 outbox/", cmd: "claude --output outbox/result.json" },
        { label: "任务完成后写入 .status 文件通知调度器", cmd: "echo done > .status" },
        { label: "start-qwen.bat 同样改造（gongbu/liyibu/zhongshusheng）", cmd: "见配置指南步骤4" },
      ],
    },
    {
      category: "main.py 调度器",
      icon: "🐍",
      color: "text-green-600",
      items: [
        { label: "实现 dispatch_message() 消息分发函数", cmd: "见配置指南步骤3" },
        { label: "实现 start_agent() 启动 bat 文件", cmd: "subprocess.Popen([bat], shell=True)" },
        { label: "实现消息监听循环（轮询 outbox/）", cmd: "while True: check_outbox(); sleep(1)" },
        { label: "配置 prompts.py 各智能体提示词", cmd: "见配置指南步骤5" },
      ],
    },
    {
      category: "连通验证",
      icon: "🧪",
      color: "text-red-600",
      items: [
        { label: "手动写入 inbox/test.json 测试单个智能体", cmd: '{"task_id":"t1","from":"test","command":"你好"}' },
        { label: "验证 outbox/result.json 有输出", cmd: "dir D:\\sslb\\gongbu\\outbox\\" },
        { label: "测试 zhongshusheng → gongbu 完整链路", cmd: "python main.py --test-chain" },
        { label: "查看 reports/ 确认报告生成", cmd: "dir D:\\sslb\\zhongshusheng\\reports\\" },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-900">
      {/* Header */}
      <header className="bg-black/30 backdrop-blur-md border-b border-white/10 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center text-lg">
              👑
            </div>
            <div>
              <h1 className="text-white font-bold text-lg leading-none">SSLB 多智能体协调系统</h1>
              <p className="text-white/50 text-xs">三省六部制 · AI Agent Orchestrator</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-green-500/20 border border-green-500/30 rounded-full px-3 py-1">
              <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
              <span className="text-green-400 text-xs font-medium">9 个智能体已配置</span>
            </div>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto px-4 pt-4">
        <div className="flex gap-1 bg-black/30 rounded-xl p-1 backdrop-blur-md border border-white/10 w-fit">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? "bg-white text-slate-900 shadow"
                  : "text-white/60 hover:text-white hover:bg-white/10"
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">

        {/* ===== 系统总览 ===== */}
        {activeTab === "overview" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left: Diagram */}
            <div className="lg:col-span-2 bg-white rounded-2xl shadow-xl p-6">
              <h2 className="text-lg font-bold text-gray-800 mb-1">🏛️ 三省六部 层级架构</h2>
              <p className="text-sm text-gray-500 mb-6">点击节点查看详细配置</p>
              <FlowDiagram
                onSelectAgent={(a) => { setSelectedAgent(a); setDetailAgent(a); }}
                selectedId={selectedAgent?.id ?? null}
              />
            </div>

            {/* Right: Agent List */}
            <div className="space-y-3">
              <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/10 p-4">
                <h2 className="text-white font-bold mb-3 flex items-center gap-2">
                  <span>🤖</span> 智能体列表
                </h2>
                <div className="space-y-2">
                  {agents.map((agent) => (
                    <AgentCard
                      key={agent.id}
                      agent={agent}
                      onClick={(a) => { setSelectedAgent(a); setDetailAgent(a); }}
                      selected={selectedAgent?.id === agent.id}
                    />
                  ))}
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/10 p-4">
                <h3 className="text-white font-bold mb-3">📊 系统统计</h3>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: "总智能体数", value: "9", color: "text-yellow-400" },
                    { label: "Claude 实例", value: "9", color: "text-orange-400" },
                    { label: "Qwen 实例", value: "3", color: "text-blue-400" },
                    { label: "层级深度", value: "3", color: "text-green-400" },
                  ].map((s) => (
                    <div key={s.label} className="bg-white/5 rounded-lg p-2 text-center">
                      <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
                      <div className="text-white/50 text-xs">{s.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===== 配置指南 ===== */}
        {activeTab === "config" && (
          <div className="max-w-3xl">
            <div className="bg-white/10 backdrop-blur-md border border-white/10 rounded-2xl p-5 mb-5">
              <h2 className="text-white font-bold text-lg mb-1">⚙️ 连通配置指南</h2>
              <p className="text-white/60 text-sm">
                按以下步骤配置，可实现各智能体通过文件系统进行消息传递，无需网络服务
              </p>
            </div>
            <div className="space-y-3">
              {configSteps.map((step, i) => (
                <ConfigStep key={step.step} step={step} defaultOpen={i === 0} />
              ))}
            </div>

            {/* Architecture note */}
            <div className="mt-6 bg-indigo-900/50 border border-indigo-500/30 rounded-2xl p-5">
              <h3 className="text-indigo-300 font-bold mb-3">💡 推荐通信架构：文件系统消息总线</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  {
                    title: "方案A：文件轮询（推荐）",
                    desc: "各智能体通过读写 JSON 文件通信，main.py 轮询检测新文件并路由",
                    pros: "无需额外服务，简单可靠",
                    color: "border-green-500",
                  },
                  {
                    title: "方案B：命名管道",
                    desc: "使用 Windows 命名管道实现实时通信",
                    pros: "延迟低，实时性好",
                    color: "border-blue-500",
                  },
                  {
                    title: "方案C：本地HTTP API",
                    desc: "每个智能体运行小型 Flask/FastAPI 服务",
                    pros: "功能最完整，支持并发",
                    color: "border-purple-500",
                  },
                ].map((opt) => (
                  <div key={opt.title} className={`border ${opt.color} rounded-xl p-3 bg-white/5`}>
                    <div className="text-white font-semibold text-sm mb-1">{opt.title}</div>
                    <div className="text-white/60 text-xs mb-2">{opt.desc}</div>
                    <div className="text-green-400 text-xs">✓ {opt.pros}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ===== 消息流转 ===== */}
        {activeTab === "flow" && (
          <div className="max-w-3xl">
            <div className="bg-white/10 backdrop-blur-md border border-white/10 rounded-2xl p-5 mb-5">
              <h2 className="text-white font-bold text-lg mb-1">📬 消息流转模拟</h2>
              <p className="text-white/60 text-sm">
                演示一个任务从触发到完成，在各智能体之间传递的完整流程
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-xl p-6">
              <MessageFlow />
            </div>

            {/* Message format spec */}
            <div className="mt-5 bg-white rounded-2xl shadow-xl p-6">
              <h3 className="font-bold text-gray-800 mb-4">📐 标准消息格式规范</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <div className="text-sm font-semibold text-gray-600 mb-2">📥 命令消息（上→下）</div>
                  <pre className="bg-gray-900 text-green-400 text-xs rounded-xl p-4">
{`{
  "task_id": "task_20250101_001",
  "from": "zhongshusheng",
  "to": "shangshusheng",
  "type": "command",
  "priority": "high",
  "content": "执行数据分析任务",
  "context": {
    "data_source": "path/to/data",
    "output_format": "markdown"
  },
  "timestamp": "2025-01-01T10:00:00Z",
  "deadline": "2025-01-01T12:00:00Z"
}`}
                  </pre>
                </div>
                <div>
                  <div className="text-sm font-semibold text-gray-600 mb-2">📤 结果消息（下→上）</div>
                  <pre className="bg-gray-900 text-cyan-400 text-xs rounded-xl p-4">
{`{
  "task_id": "task_20250101_001",
  "from": "gongbu",
  "to": "shangshusheng",
  "type": "result",
  "status": "done",
  "summary": "已完成数据分析",
  "artifacts": [
    "reports/20250101_analysis.md"
  ],
  "metrics": {
    "duration_sec": 45,
    "tokens_used": 2048
  },
  "timestamp": "2025-01-01T10:45:00Z"
}`}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===== 连通检查 ===== */}
        {activeTab === "checklist" && (
          <div className="max-w-3xl space-y-4">
            <div className="bg-white/10 backdrop-blur-md border border-white/10 rounded-2xl p-5">
              <h2 className="text-white font-bold text-lg mb-1">✅ 连通检查清单</h2>
              <p className="text-white/60 text-sm">
                按照以下清单逐项完成，即可实现各智能体联通
              </p>
            </div>

            {checklistItems.map((section) => (
              <div key={section.category} className="bg-white rounded-2xl shadow-xl overflow-hidden">
                <div className="px-5 py-3 bg-gray-50 border-b border-gray-100 flex items-center gap-2">
                  <span className="text-xl">{section.icon}</span>
                  <h3 className={`font-bold ${section.color}`}>{section.category}</h3>
                </div>
                <div className="divide-y divide-gray-50">
                  {section.items.map((item, i) => (
                    <ChecklistRow key={i} label={item.label} cmd={item.cmd} />
                  ))}
                </div>
              </div>
            ))}

            {/* Quick start commands */}
            <div className="bg-white rounded-2xl shadow-xl p-6">
              <h3 className="font-bold text-gray-800 mb-4">🚀 一键初始化脚本</h3>
              <p className="text-sm text-gray-500 mb-3">创建 <code className="bg-gray-100 px-1 rounded">D:\sslb\init.bat</code> 并运行：</p>
              <pre className="bg-gray-900 text-yellow-400 text-xs rounded-xl p-4 overflow-x-auto">
{`@echo off
REM SSLB 多智能体系统初始化脚本
SET ROOT=D:\\sslb

REM 创建全局消息总线
mkdir %ROOT%\\.bus
mkdir %ROOT%\\.bus\\logs

REM 为每个智能体创建 inbox/outbox
for %%d in (zhongshusheng menxiasheng shangshusheng libu hubu liyibu bingbu xingbu gongbu) do (
    mkdir %ROOT%\\%%d\\inbox
    mkdir %ROOT%\\%%d\\outbox
    echo {} > %ROOT%\\%%d\\.status
    echo 初始化 %%d 完成
)

echo.
echo ✅ 初始化完成！现在请：
echo 1. 更新各 CLAUDE.md 配置文件
echo 2. 修改各 .bat 文件加入 inbox/outbox 读写
echo 3. 运行 python main.py 启动调度器
pause`}
              </pre>
            </div>
          </div>
        )}
      </main>

      {/* Agent Detail Modal */}
      {detailAgent && (
        <AgentDetail agent={detailAgent} onClose={() => setDetailAgent(null)} />
      )}

      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(-8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

function ChecklistRow({ label, cmd }: { label: string; cmd: string }) {
  const [checked, setChecked] = useState(false);
  return (
    <div
      className={`flex items-start gap-3 px-5 py-3 cursor-pointer hover:bg-gray-50 transition-colors ${checked ? "opacity-60" : ""}`}
      onClick={() => setChecked(!checked)}
    >
      <div className={`mt-0.5 w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
        checked ? "bg-green-500 border-green-500" : "border-gray-300"
      }`}>
        {checked && <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
        </svg>}
      </div>
      <div className="flex-1 min-w-0">
        <div className={`text-sm ${checked ? "line-through text-gray-400" : "text-gray-700"}`}>{label}</div>
        <code className="text-xs text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded mt-0.5 inline-block">{cmd}</code>
      </div>
    </div>
  );
}
