import { useState } from "react";
import { configSections } from "./data/config";
import SectionPanel from "./components/SectionPanel";

type Tab = "guide" | "arch" | "flow";

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("guide");

  const tabs: { id: Tab; icon: string; label: string }[] = [
    { id: "guide", icon: "📋", label: "配置指南" },
    { id: "arch", icon: "🏛️", label: "系统架构" },
    { id: "flow", icon: "📬", label: "消息流转" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950">
      {/* ── Header ── */}
      <header className="sticky top-0 z-30 bg-black/40 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center text-lg shadow-lg">
              👑
            </div>
            <div>
              <h1 className="text-white font-bold text-base leading-none">SSLB 多智能体协调系统</h1>
              <p className="text-white/40 text-xs mt-0.5">三省六部制 · 联通配置指南</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-1.5 bg-green-500/15 border border-green-500/25 rounded-full px-3 py-1">
              <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
              <span className="text-green-400 text-xs font-medium">9 个智能体</span>
            </div>
          </div>
        </div>
      </header>

      {/* ── Tabs ── */}
      <div className="max-w-5xl mx-auto px-4 pt-5">
        <div className="flex gap-1 bg-black/30 rounded-xl p-1 backdrop-blur-md border border-white/10 w-fit">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? "bg-white text-slate-900 shadow"
                  : "text-white/50 hover:text-white hover:bg-white/10"
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ── Main Content ── */}
      <main className="max-w-5xl mx-auto px-4 py-6">

        {/* ════ 配置指南 ════ */}
        {activeTab === "guide" && (
          <div>
            {/* Banner */}
            <div className="bg-gradient-to-r from-indigo-900/60 to-blue-900/60 border border-indigo-500/30 rounded-2xl p-5 mb-6 backdrop-blur-sm">
              <h2 className="text-white font-bold text-xl mb-2">🚀 如何将 9 个智能体联通？</h2>
              <p className="text-white/70 text-sm mb-4">
                按以下 5 个步骤完成配置，即可实现通过文件系统消息总线让各智能体自动通信、路由、执行任务。
              </p>
              <div className="flex flex-wrap gap-2">
                {configSections.map((s) => (
                  <div key={s.id} className="flex items-center gap-1.5 bg-white/10 rounded-full px-3 py-1 text-sm text-white/80">
                    <span>{s.icon}</span>
                    <span>步骤{s.step}：{s.title}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Start Command */}
            <div className="bg-black/40 border border-white/10 rounded-2xl p-5 mb-6 backdrop-blur-sm">
              <h3 className="text-white font-bold mb-3 flex items-center gap-2">
                <span>⚡</span> 快速开始（配置完成后）
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {[
                  {
                    step: "1", icon: "🗂️", label: "初始化目录",
                    cmd: "D:\\sslb\\init.bat",
                    desc: "创建所有通信目录"
                  },
                  {
                    step: "2", icon: "🐍", label: "启动调度器",
                    cmd: "python main.py --mode orchestrator",
                    desc: "在 my_agent_project/ 下运行"
                  },
                  {
                    step: "3", icon: "📤", label: "发送任务",
                    cmd: "python main.py --mode send --to-agent zhongshusheng --command \"执行任务\"",
                    desc: "触发完整链路"
                  },
                ].map((item) => (
                  <div key={item.step} className="bg-white/5 rounded-xl p-3 border border-white/10">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-lg">{item.icon}</span>
                      <span className="text-white font-semibold text-sm">{item.label}</span>
                    </div>
                    <code className="block text-xs text-yellow-300 bg-black/30 rounded-lg p-2 font-mono break-all">
                      {item.cmd}
                    </code>
                    <p className="text-white/40 text-xs mt-1.5">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Config Steps */}
            <div className="space-y-4">
              {configSections.map((section, i) => (
                <SectionPanel key={section.id} section={section} defaultOpen={i === 0} />
              ))}
            </div>

            {/* Footer Note */}
            <div className="mt-6 bg-amber-900/30 border border-amber-500/30 rounded-2xl p-5">
              <h3 className="text-amber-300 font-bold mb-3">⚠️ 常见问题</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  {
                    q: "Claude 输出不是 JSON 怎么办？",
                    a: "在 CLAUDE.md 中更明确地要求：\"你的回复必须只包含 JSON，不要输出任何额外文字\""
                  },
                  {
                    q: "bat 文件中文显示乱码？",
                    a: "已在脚本顶部加入 chcp 65001，确保控制台编码为 UTF-8"
                  },
                  {
                    q: "调度器看不到结果文件？",
                    a: "检查 outbox/ 中文件名是否包含 result_ 前缀，调度器用 glob('*.json') 扫描"
                  },
                  {
                    q: "Qwen API 调用失败？",
                    a: "先运行 pip install dashscope，然后在 start-qwen.bat 中填入正确的 QWEN_API_KEY"
                  },
                ].map((faq, i) => (
                  <div key={i} className="bg-amber-900/20 rounded-xl p-3">
                    <div className="text-amber-200 font-semibold text-sm mb-1">Q: {faq.q}</div>
                    <div className="text-amber-100/70 text-sm">A: {faq.a}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ════ 系统架构 ════ */}
        {activeTab === "arch" && <ArchView />}

        {/* ════ 消息流转 ════ */}
        {activeTab === "flow" && <FlowView />}

      </main>
    </div>
  );
}

// ── 系统架构视图 ──
function ArchView() {
  const layers = [
    {
      name: "决策层",
      color: "from-yellow-500 to-amber-600",
      textColor: "text-yellow-100",
      bgLight: "bg-yellow-500/20",
      borderColor: "border-yellow-500/40",
      agents: [
        { icon: "👑", name: "中书省", id: "zhongshusheng", desc: "最高决策·政令起草", bats: ["start-claude.bat", "start-qwen.bat"] },
      ],
    },
    {
      name: "审核层",
      color: "from-blue-500 to-indigo-600",
      textColor: "text-blue-100",
      bgLight: "bg-blue-500/20",
      borderColor: "border-blue-500/40",
      agents: [
        { icon: "🔍", name: "门下省", id: "menxiasheng", desc: "审核复议·监督执行", bats: ["start-claude.bat"] },
      ],
    },
    {
      name: "调度层",
      color: "from-purple-500 to-violet-600",
      textColor: "text-purple-100",
      bgLight: "bg-purple-500/20",
      borderColor: "border-purple-500/40",
      agents: [
        { icon: "⚖️", name: "尚书省", id: "shangshusheng", desc: "执行调度·任务分发", bats: ["start-claude.bat"] },
      ],
    },
    {
      name: "执行层（六部）",
      color: "from-emerald-500 to-teal-600",
      textColor: "text-emerald-100",
      bgLight: "bg-emerald-500/20",
      borderColor: "border-emerald-500/40",
      agents: [
        { icon: "📋", name: "吏部", id: "libu", desc: "人事管理", bats: ["start-claude.bat"] },
        { icon: "💰", name: "户部", id: "hubu", desc: "资源统计", bats: ["start-claude.bat"] },
        { icon: "🎭", name: "礼仪部", id: "liyibu", desc: "规范制定", bats: ["start-claude.bat", "start-qwen.bat"] },
        { icon: "⚔️", name: "兵部", id: "bingbu", desc: "安全防护", bats: ["start-claude.bat"] },
        { icon: "⚖️", name: "刑部", id: "xingbu", desc: "合规审计", bats: ["start-claude.bat"] },
        { icon: "🔧", name: "工部", id: "gongbu", desc: "技术执行", bats: ["start-claude.bat", "start-qwen.bat"] },
      ],
    },
  ];

  return (
    <div>
      <div className="bg-black/40 border border-white/10 rounded-2xl p-5 mb-6 backdrop-blur-sm">
        <h2 className="text-white font-bold text-xl mb-1">🏛️ 三省六部系统架构</h2>
        <p className="text-white/60 text-sm">命令从上往下传递，结果从下往上汇报。消息格式统一为 JSON，通过文件系统传递。</p>
      </div>

      {/* Architecture Diagram */}
      <div className="space-y-3">
        {layers.map((layer, li) => (
          <div key={layer.name}>
            {/* Arrow between layers */}
            {li > 0 && (
              <div className="flex flex-col items-center py-1">
                <div className="flex items-center gap-8 text-white/30 text-xs mb-0.5">
                  <span>← 结果上报</span>
                  <span className="text-white/50">↕ inbox/outbox</span>
                  <span>命令下发 →</span>
                </div>
                <div className="w-px h-4 bg-white/20" />
                <div className="text-white/30 text-base">▼</div>
              </div>
            )}
            <div className={`${layer.bgLight} border ${layer.borderColor} rounded-2xl p-4`}>
              <div className="text-xs font-bold text-white/50 uppercase tracking-wider mb-3">{layer.name}</div>
              <div className={`grid gap-3 ${layer.agents.length === 1 ? "grid-cols-1 max-w-sm" : "grid-cols-2 md:grid-cols-3 lg:grid-cols-6"}`}>
                {layer.agents.map((agent) => (
                  <div key={agent.id} className="bg-white/10 rounded-xl p-3 border border-white/10 hover:bg-white/15 transition-colors">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xl">{agent.icon}</span>
                      <div>
                        <div className={`font-bold text-sm ${layer.textColor}`}>{agent.name}</div>
                        <div className="text-white/40 text-xs">{agent.desc}</div>
                      </div>
                    </div>
                    <div className="space-y-1">
                      {agent.bats.map((bat) => (
                        <div key={bat} className="flex items-center gap-1">
                          <span className="text-xs">{bat.includes("qwen") ? "🟣" : "🟠"}</span>
                          <code className="text-white/50 text-xs">{bat}</code>
                        </div>
                      ))}
                    </div>
                    <div className="mt-2 pt-2 border-t border-white/10">
                      <code className="text-white/30 text-xs">{agent.id}/</code>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Communication Diagram */}
      <div className="mt-6 bg-white/5 border border-white/10 rounded-2xl p-5">
        <h3 className="text-white font-bold mb-4">📡 通信机制</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              icon: "📁",
              title: "文件系统总线",
              desc: "每个智能体有 inbox/ 和 outbox/ 两个目录，通过写入 JSON 文件实现异步通信",
              example: "D:\\sslb\\gongbu\\inbox\\task_001.json",
              color: "border-blue-500/30 bg-blue-500/10",
            },
            {
              icon: "🐍",
              title: "Python 调度器",
              desc: "main.py 每秒轮询 outbox/，发现新文件即路由到上级，并启动对应 .bat",
              example: "python main.py --mode orchestrator",
              color: "border-yellow-500/30 bg-yellow-500/10",
            },
            {
              icon: "🦇",
              title: "Bat 文件触发",
              desc: "调度器通过 subprocess + 环境变量 TASK_FILE 启动智能体，Claude 读文件处理",
              example: "SET TASK_FILE=... && start-claude.bat",
              color: "border-purple-500/30 bg-purple-500/10",
            },
          ].map((item) => (
            <div key={item.title} className={`border ${item.color} rounded-xl p-4`}>
              <div className="text-2xl mb-2">{item.icon}</div>
              <div className="text-white font-semibold mb-2">{item.title}</div>
              <div className="text-white/60 text-sm mb-3">{item.desc}</div>
              <code className="text-xs text-white/40 bg-black/30 rounded px-2 py-1 block break-all">{item.example}</code>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── 消息流转视图 ──
function FlowView() {
  const [step, setStep] = useState(0);

  const steps = [
    {
      icon: "👤",
      from: "用户",
      to: "中书省",
      action: "发送任务",
      file: "zhongshusheng/inbox/task_001.json",
      color: "bg-gray-500",
      lineColor: "bg-gray-400",
      code: `{
  "task_id": "task_001",
  "from": "human",
  "to": "zhongshusheng",
  "type": "command",
  "priority": "high",
  "content": "生成一个数据分析 Python 脚本"
}`,
    },
    {
      icon: "👑",
      from: "中书省",
      to: "尚书省",
      action: "下发命令",
      file: "shangshusheng/inbox/task_001.json",
      color: "bg-yellow-500",
      lineColor: "bg-yellow-400",
      code: `{
  "task_id": "task_001",
  "from": "zhongshusheng",
  "to": "shangshusheng",
  "type": "command",
  "priority": "high",
  "content": "分配技术执行任务给工部"
}`,
    },
    {
      icon: "⚖️",
      from: "尚书省",
      to: "工部",
      action: "分派任务",
      file: "gongbu/inbox/task_001.json",
      color: "bg-purple-500",
      lineColor: "bg-purple-400",
      code: `{
  "task_id": "task_001",
  "from": "shangshusheng",
  "to": "gongbu",
  "type": "command",
  "content": "生成 Python 数据分析脚本",
  "priority": "high"
}`,
    },
    {
      icon: "🔧",
      from: "工部",
      to: "尚书省",
      action: "返回结果",
      file: "gongbu/outbox/result_task_001.json",
      color: "bg-cyan-500",
      lineColor: "bg-cyan-400",
      code: `{
  "task_id": "task_001",
  "from": "gongbu",
  "to": "shangshusheng",
  "type": "result",
  "status": "done",
  "summary": "已生成 pandas 数据分析脚本",
  "artifacts": ["reports/20250101_task_001.md"],
  "metrics": {"tokens_used": 1024}
}`,
    },
    {
      icon: "⚖️",
      from: "尚书省",
      to: "中书省",
      action: "汇报结果",
      file: "zhongshusheng/inbox/result_task_001.json",
      color: "bg-purple-500",
      lineColor: "bg-purple-400",
      code: `{
  "task_id": "task_001",
  "from": "shangshusheng",
  "to": "zhongshusheng",
  "type": "result",
  "status": "done",
  "summary": "六部任务全部完成",
  "artifacts": ["gongbu/reports/xxx.md"]
}`,
    },
  ];

  return (
    <div>
      <div className="bg-black/40 border border-white/10 rounded-2xl p-5 mb-6 backdrop-blur-sm">
        <h2 className="text-white font-bold text-xl mb-1">📬 消息流转演示</h2>
        <p className="text-white/60 text-sm">点击步骤按钮，逐步查看一个任务从用户发起到工部完成的完整链路</p>
      </div>

      {/* Step Buttons */}
      <div className="flex flex-wrap gap-2 mb-6">
        {steps.map((s, i) => (
          <button
            key={i}
            onClick={() => setStep(i)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
              step === i
                ? `${s.color} text-white shadow-lg scale-105`
                : "bg-white/10 text-white/60 hover:bg-white/20 hover:text-white"
            }`}
          >
            <span>{s.icon}</span>
            <span>第{i + 1}步</span>
          </button>
        ))}
      </div>

      {/* Flow visualization */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-6 mb-4">
        <div className="flex items-center gap-4 mb-6">
          <div className={`${steps[step].color} text-white text-2xl w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg`}>
            {steps[step].icon}
          </div>
          <div>
            <div className="text-white font-bold text-lg">
              {steps[step].from} → {steps[step].to}
            </div>
            <div className="text-white/50">{steps[step].action}</div>
          </div>
          <div className="ml-auto">
            <div className="text-xs text-white/40 mb-1">写入文件</div>
            <code className="text-xs text-white/60 bg-black/30 px-2 py-1 rounded-lg">
              {steps[step].file}
            </code>
          </div>
        </div>

        {/* Progress */}
        <div className="flex items-center gap-1 mb-6">
          {steps.map((s, i) => (
            <div key={i} className="flex items-center gap-1 flex-1">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                i <= step ? `${s.color} text-white` : "bg-white/10 text-white/30"
              }`}>
                {i < step ? "✓" : i + 1}
              </div>
              {i < steps.length - 1 && (
                <div className={`flex-1 h-1 rounded-full transition-all ${i < step ? s.lineColor : "bg-white/10"}`} />
              )}
            </div>
          ))}
        </div>

        {/* Message JSON */}
        <div>
          <div className="text-sm text-white/50 mb-2 font-medium">消息内容（JSON）</div>
          <pre className="bg-gray-900/80 text-green-400 text-sm rounded-xl p-4 overflow-x-auto leading-relaxed font-mono">
            {steps[step].code}
          </pre>
        </div>
      </div>

      {/* Nav buttons */}
      <div className="flex justify-between">
        <button
          onClick={() => setStep(Math.max(0, step - 1))}
          disabled={step === 0}
          className="flex items-center gap-2 px-5 py-2.5 bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed text-white rounded-xl transition-colors font-medium"
        >
          ← 上一步
        </button>
        <span className="text-white/40 text-sm self-center">
          {step + 1} / {steps.length}
        </span>
        <button
          onClick={() => setStep(Math.min(steps.length - 1, step + 1))}
          disabled={step === steps.length - 1}
          className="flex items-center gap-2 px-5 py-2.5 bg-indigo-500 hover:bg-indigo-400 disabled:opacity-30 disabled:cursor-not-allowed text-white rounded-xl transition-colors font-medium"
        >
          下一步 →
        </button>
      </div>

      {/* Message Format Reference */}
      <div className="mt-6 bg-white/5 border border-white/10 rounded-2xl p-5">
        <h3 className="text-white font-bold mb-4">📐 消息格式标准规范</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <div className="text-sm font-semibold text-white/70 mb-2">📥 命令消息（上→下）必填字段</div>
            <div className="space-y-1.5">
              {[
                { field: "task_id", type: "string", desc: "唯一任务ID，格式 task_YYYYMMDD_序号" },
                { field: "from", type: "string", desc: "发送方 agent_id" },
                { field: "to", type: "string", desc: "接收方 agent_id" },
                { field: "type", type: '"command"', desc: "消息类型（命令）" },
                { field: "priority", type: '"high|medium|low"', desc: "优先级" },
                { field: "content", type: "string", desc: "具体指令内容" },
              ].map((f) => (
                <div key={f.field} className="flex items-start gap-2 text-xs bg-black/20 rounded-lg px-3 py-1.5">
                  <code className="text-cyan-300 w-20 flex-shrink-0">{f.field}</code>
                  <code className="text-yellow-300 w-24 flex-shrink-0">{f.type}</code>
                  <span className="text-white/50">{f.desc}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-white/70 mb-2">📤 结果消息（下→上）必填字段</div>
            <div className="space-y-1.5">
              {[
                { field: "task_id", type: "string", desc: "继承原始 task_id" },
                { field: "from", type: "string", desc: "执行方 agent_id" },
                { field: "to", type: "string", desc: "上级 agent_id" },
                { field: "type", type: '"result"', desc: "消息类型（结果）" },
                { field: "status", type: '"done|failed"', desc: "执行状态" },
                { field: "summary", type: "string", desc: "执行摘要（≤200字）" },
                { field: "artifacts", type: "string[]", desc: "生成的文件路径列表" },
              ].map((f) => (
                <div key={f.field} className="flex items-start gap-2 text-xs bg-black/20 rounded-lg px-3 py-1.5">
                  <code className="text-cyan-300 w-20 flex-shrink-0">{f.field}</code>
                  <code className="text-yellow-300 w-24 flex-shrink-0">{f.type}</code>
                  <span className="text-white/50">{f.desc}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
