import { useState } from "react";

interface Props {
  code: string;
  language?: string;
  maxHeight?: string;
}

const LANG_COLORS: Record<string, string> = {
  python: "text-blue-300",
  bat: "text-yellow-300",
  markdown: "text-green-300",
  json: "text-cyan-300",
};

const LANG_LABELS: Record<string, string> = {
  python: "Python",
  bat: "Batch",
  markdown: "Markdown",
  json: "JSON",
};

export default function CodeBlock({ code, language = "text", maxHeight = "400px" }: Props) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const langColor = LANG_COLORS[language] || "text-gray-300";
  const langLabel = LANG_LABELS[language] || language;

  return (
    <div className="rounded-xl overflow-hidden border border-gray-700 shadow-lg">
      {/* Header bar */}
      <div className="flex items-center justify-between bg-gray-800 px-4 py-2">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/70" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
            <div className="w-3 h-3 rounded-full bg-green-500/70" />
          </div>
          <span className={`text-xs font-mono font-semibold ml-2 ${langColor}`}>{langLabel}</span>
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white transition-colors bg-gray-700 hover:bg-gray-600 px-3 py-1 rounded-md"
        >
          {copied ? (
            <>
              <svg className="w-3.5 h-3.5 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
              <span className="text-green-400">已复制</span>
            </>
          ) : (
            <>
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              <span>复制代码</span>
            </>
          )}
        </button>
      </div>
      {/* Code area */}
      <div className="bg-gray-900" style={{ maxHeight, overflowY: "auto" }}>
        <pre className="text-sm text-gray-100 p-4 leading-relaxed font-mono whitespace-pre overflow-x-auto">
          {code}
        </pre>
      </div>
    </div>
  );
}
