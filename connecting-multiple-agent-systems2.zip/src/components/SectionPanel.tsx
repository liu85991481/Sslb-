import { useState } from "react";
import { ConfigSection } from "../data/config";
import CodeBlock from "./CodeBlock";

interface Props {
  section: ConfigSection;
  defaultOpen?: boolean;
}

export default function SectionPanel({ section, defaultOpen = false }: Props) {
  const [open, setOpen] = useState(defaultOpen);
  const [activeFile, setActiveFile] = useState(0);

  const file = section.files[activeFile];

  return (
    <div className={`rounded-2xl border-2 ${section.borderColor} overflow-hidden shadow-md`}>
      {/* Header */}
      <button
        onClick={() => setOpen(!open)}
        className={`w-full flex items-center gap-4 px-6 py-4 ${section.bgColor} hover:brightness-95 transition-all text-left`}
      >
        <div className="w-10 h-10 rounded-xl bg-white/60 flex items-center justify-center text-2xl flex-shrink-0 shadow-sm">
          {section.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className={`text-xs font-bold uppercase tracking-wider ${section.textColor} opacity-70`}>
              步骤 {section.step}
            </span>
          </div>
          <div className={`font-bold text-lg ${section.color} leading-tight`}>{section.title}</div>
          <div className="text-sm text-gray-500 mt-0.5">{section.subtitle}</div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <span className="text-xs bg-white/60 rounded-full px-2 py-0.5 text-gray-500 font-medium">
            {section.files.length} 个文件
          </span>
          <svg
            className={`w-5 h-5 text-gray-400 transition-transform ${open ? "rotate-180" : ""}`}
            fill="none" viewBox="0 0 24 24" stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </button>

      {open && (
        <div className="bg-white">
          {/* Notes */}
          {section.notes && section.notes.length > 0 && (
            <div className="px-6 py-4 border-b border-gray-100">
              <div className="flex flex-wrap gap-2">
                {section.notes.map((note, i) => (
                  <div key={i} className="flex items-start gap-1.5 text-sm text-gray-600 bg-gray-50 rounded-lg px-3 py-1.5">
                    <span className="text-amber-500 mt-0.5 flex-shrink-0">💡</span>
                    <span>{note}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* File tabs */}
          {section.files.length > 1 && (
            <div className="flex gap-1 px-6 pt-4 overflow-x-auto">
              {section.files.map((f, i) => (
                <button
                  key={i}
                  onClick={() => setActiveFile(i)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                    activeFile === i
                      ? "bg-gray-900 text-white"
                      : "text-gray-500 hover:text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  <FileIcon language={f.language} />
                  {f.filename}
                </button>
              ))}
            </div>
          )}

          {/* File content */}
          <div className="px-6 pb-6 pt-4">
            <div className="mb-3 flex items-start justify-between gap-3">
              <div>
                <div className="font-semibold text-gray-800 flex items-center gap-2">
                  <FileIcon language={file.language} />
                  {file.filename}
                </div>
                <div className="text-sm text-gray-500 mt-0.5">{file.description}</div>
              </div>
              <code className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-md font-mono flex-shrink-0 mt-1 hidden md:block">
                {file.path}
              </code>
            </div>
            <CodeBlock
              code={file.content}
              language={file.language}
              maxHeight="500px"
            />
          </div>
        </div>
      )}
    </div>
  );
}

function FileIcon({ language }: { language: string }) {
  const icons: Record<string, string> = {
    python: "🐍",
    bat: "⚙️",
    markdown: "📝",
    json: "📋",
  };
  return <span className="text-sm">{icons[language] || "📄"}</span>;
}
